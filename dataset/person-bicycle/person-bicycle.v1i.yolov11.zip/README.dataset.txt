# person-bicycle > 2025-04-12 3:11pm
https://universe.roboflow.com/xattatrone/person-bicycle

Provided by a Roboflow user
License: CC BY 4.0

